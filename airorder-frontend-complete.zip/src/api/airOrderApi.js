import axios from 'axios';

const useMock = import.meta.env.VITE_USE_MOCK === 'true';
const baseURL = useMock ? '' : 'http://localhost:9090';

export const fetchAllOrders = () =>
  axios.get(`${baseURL}/api/queryallairorders`).then((res) => JSON.parse(res.data.response));

export const fetchOrderById = (id) =>
  axios.get(`${baseURL}/api/queryairorderbyid/${id}`).then((res) => JSON.parse(res.data.response));

export const addAirOrder = (data) =>
  axios.post(`${baseURL}/api/addairorder`, data);

export const changeOrderStatus = (id, newStatus) =>
  axios.put(`${baseURL}/api/changeairorderstatus/${id}`, { newStatus });
