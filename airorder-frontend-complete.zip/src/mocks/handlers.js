import { http } from 'msw';

export const handlers = [
  http.get('/api/queryallairorders', (req, res, ctx) => {
    return res(ctx.status(200), ctx.json({
      response: JSON.stringify([
        { id: '1', issuer: 'Amadeus', status: 'Open', amount: '1234' },
        { id: '2', issuer: 'Sabre', status: 'Closed', amount: '4567' }
      ])
    }));
  }),

  http.get('/api/queryairorderbyid/:id', (req, res, ctx) => {
    return res(ctx.status(200), ctx.json({
      response: JSON.stringify({ id: req.params.id, issuer: 'Amadeus', status: 'Open', amount: '1234' })
    }));
  }),

  http.post('/api/addairorder', async (req, res, ctx) => {
    return res(ctx.status(200), ctx.text('Transaction has been submitted'));
  }),

  http.put('/api/changeairorderstatus/:id', async (req, res, ctx) => {
    return res(ctx.status(200), ctx.text('Transaction has been submitted'));
  }),
];
