import React, { useEffect, useState } from 'react';
import { fetchAllOrders } from '../api/airOrderApi';

const AirOrderList = () => {
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    fetchAllOrders().then(setOrders);
  }, []);

  return (
    <div className="bg-white shadow rounded-lg p-4">
      <h2 className="text-xl font-semibold mb-2">Air Orders</h2>
      <ul className="space-y-2">
        {orders.map((o) => (
          <li key={o.id} className="border p-2 rounded-md">
            <span className="font-medium">#{o.id}</span> - {o.issuer} - {o.status} - ${o.amount}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default AirOrderList;
