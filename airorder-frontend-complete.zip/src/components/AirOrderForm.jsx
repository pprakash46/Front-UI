import React, { useState } from 'react';
import { addAirOrder } from '../api/airOrderApi';

const AirOrderForm = () => {
  const [form, setForm] = useState({ id: '', issuer: '', status: '', amount: '' });

  const handleSubmit = async (e) => {
    e.preventDefault();
    await addAirOrder(form);
    alert('Submitted!');
  };

  return (
    <form onSubmit={handleSubmit} className="bg-white shadow rounded-lg p-4 space-y-3">
      <h2 className="text-lg font-semibold">Add Air Order</h2>
      <input className="w-full border rounded p-2" placeholder="ID" onChange={(e) => setForm({...form, id: e.target.value})} />
      <input className="w-full border rounded p-2" placeholder="Issuer" onChange={(e) => setForm({...form, issuer: e.target.value})} />
      <input className="w-full border rounded p-2" placeholder="Status" onChange={(e) => setForm({...form, status: e.target.value})} />
      <input className="w-full border rounded p-2" placeholder="Amount" onChange={(e) => setForm({...form, amount: e.target.value})} />
      <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Add Order</button>
    </form>
  );
};

export default AirOrderForm;
